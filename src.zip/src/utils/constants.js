const BASE_URL = "http://localhost:7777";

export {BASE_URL};
